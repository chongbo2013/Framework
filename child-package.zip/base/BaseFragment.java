package com.zipingfang.anshijie.base;

/**
 * Created by Liux on 2017/11/6.
 */

public abstract class BaseFragment extends com.liux.base.BaseFragment {
}
