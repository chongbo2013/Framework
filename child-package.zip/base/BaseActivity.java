package com.zipingfang.anshijie.base;

/**
 * Created by Liux on 2017/11/6.
 */

public abstract class BaseActivity extends com.liux.base.BaseActivity {
}
