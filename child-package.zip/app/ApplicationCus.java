package com.zipingfang.anshijie.app;

import android.app.Application;
import android.content.Context;
import android.support.multidex.MultiDex;

import com.liux.http.HttpClient;
import com.liux.util.DeviceUtil;

import java.util.Map;

import okhttp3.Request;

/**
 * Created by Liux on 2017/8/17.
 */

public class ApplicationCus extends Application {

    private static Context mContext;

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(base);
    }

    @Override
    public void onCreate() {
        super.onCreate();

        mContext = this;

        HttpClient.initialize(this, "");
        HttpClient.getInstance().setOnCheckParamsListener(new HttpClient.OnCheckParamsListener() {
            @Override
            public void onCheckParams(Request request, Map<String, String> params) {

            }
        });

        if (DeviceUtil.isMainProcess(this)) {

        } else {

        }
    }

    public static Context getContext() {
        return mContext;
    }
}
